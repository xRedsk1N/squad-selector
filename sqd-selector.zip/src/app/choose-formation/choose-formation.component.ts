import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-choose-formation',
  templateUrl: './choose-formation.component.html',
  styleUrls: ['./choose-formation.component.css'],
})
export class ChooseFormationComponent {
  chosenFormation: Array<number> = [];
  chosenFormNumber: number = 0;

  @Output() chooseFormationEvent = new EventEmitter<Array<number>>();

  chooseFormation(chosen: Array<number>, chosenNumber: number) {
    this.chosenFormation = chosen;
    this.chosenFormNumber = chosenNumber;
    this.chooseFormationEvent.emit(this.chosenFormation);
  }
}
