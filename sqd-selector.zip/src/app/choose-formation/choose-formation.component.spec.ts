import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChooseFormationComponent } from './choose-formation.component';

describe('ChooseFormationComponent', () => {
  let component: ChooseFormationComponent;
  let fixture: ComponentFixture<ChooseFormationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChooseFormationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChooseFormationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
