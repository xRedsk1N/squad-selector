import { Footballer } from './player';

export const PLAYERS: Footballer[] = [
  {
    shirtnr: 1,
    name: 'Wojciech',
    surname: 'Szczęsny',
    position: 'GK',
  },
  {
    shirtnr: 2,
    name: 'Matty',
    surname: 'Cash',
    position: 'DF',
  },
  {
    shirtnr: 3,
    name: 'Bartosz',
    surname: 'Bereszyński',
    position: 'DF',
  },
  {
    shirtnr: 4,
    name: 'Jakub',
    surname: 'Kiwior',
    position: 'DF',
  },
  {
    shirtnr: 5,
    name: 'Kamil',
    surname: 'Glik',
    position: 'DF',
  },
  {
    shirtnr: 6,
    name: 'Krystian',
    surname: 'Bielik',
    position: 'MF',
  },
  {
    shirtnr: 7,
    name: 'Arkadiusz',
    surname: 'Milik',
    position: 'ST',
  },
  {
    shirtnr: 8,
    name: 'Grzegorz',
    surname: 'Krychowiak',
    position: 'MF',
  },
  {
    shirtnr: 9,
    name: 'Robert',
    surname: 'Lewandowski',
    position: 'ST',
  },
  {
    shirtnr: 10,
    name: 'Piotr',
    surname: 'Zieliński',
    position: 'MF',
  },
  {
    shirtnr: 11,
    name: 'Przemysław',
    surname: 'Frankowski',
    position: 'MF',
  },
  {
    shirtnr: 12,
    name: 'Nicola',
    surname: 'Zalewski',
    position: 'DF',
  },
  {
    shirtnr: 13,
    name: 'Karol',
    surname: 'Świderski',
    position: 'ST',
  },
  {
    shirtnr: 14,
    name: 'Łukasz',
    surname: 'Fabiański',
    position: 'GK',
  },
];
