export interface Footballer {
  shirtnr: number;
  name: string;
  surname: string;
  position: string;
}
