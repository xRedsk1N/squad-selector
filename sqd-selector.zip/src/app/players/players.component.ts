import { Component } from '@angular/core';
//import { PLAYERS } from './player-list';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css'],
})
export class PlayersComponent {}
