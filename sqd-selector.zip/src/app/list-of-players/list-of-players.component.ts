import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  OnChanges,
} from '@angular/core';
import { Footballer } from '../players/player';

@Component({
  selector: 'app-list-of-players',
  templateUrl: './list-of-players.component.html',
  styleUrls: ['./list-of-players.component.css'],
})
export class ListOfPlayersComponent {
  @Input() role: string = '';
  @Input() players: Array<Footballer> = [];
  @Input() isAvailable: boolean = true;
  @Output() movePlayerEvent = new EventEmitter<Footballer>();

  ngOnInit() {
    this.players = this.players.filter(
      (player) => player.position == this.role
    );
  }

  ngOnChanges() {
    this.players = this.players.filter(
      (player) => player.position == this.role
    );
  }

  movePlayer(player: Footballer) {
    if (this.isAvailable == true) this.movePlayerEvent.emit(player);
  }
}
