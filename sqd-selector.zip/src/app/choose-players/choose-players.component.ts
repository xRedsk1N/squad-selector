import { FormatWidth } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { Footballer } from '../players/player';
//import { PLAYERS } from '../players/player-list';

@Component({
  selector: 'app-choose-players',
  templateUrl: './choose-players.component.html',
  styleUrls: ['./choose-players.component.css'],
})
export class ChoosePlayersComponent implements OnInit {
  //notSelected: Array<Footballer> = PLAYERS;
  notSelected: Footballer[] = [];
  selected: Array<Footballer> = [];
  positions = ['GK', 'DF', 'MF', 'ST'];

  playersUrl =
    'https://pilkarze-b0827-default-rtdb.europe-west1.firebasedatabase.app/players.json';

  //notselected1: Footballer[] = [];

  constructor(private http: HttpClient) {}

  @Input() formation: Array<number> = [];

  posCounter = [0, 0, 0, 0];

  ngOnInit() {
    this.http
      .get<Footballer[]>(this.playersUrl)
      .subscribe((data: Footballer[]) => {
        this.notSelected = data;
      });
  }

  posToNum(pos: string) {
    if (pos == 'GK') return 0;
    if (pos == 'DF') return 1;
    if (pos == 'MF') return 2;
    if (pos == 'ST') return 3;
    return -1;
  }

  movePlayer(player: Footballer, direction: number) {
    if (!direction) {
      this.selected = this.selected.concat([player]);
      this.notSelected = this.notSelected.filter(
        (el) => el.shirtnr != player.shirtnr
      );
      this.posCounter[this.posToNum(player.position)] += 1;
      console.log(this.posCounter);
    } else {
      this.notSelected = this.notSelected.concat([player]);
      this.selected = this.selected.filter(
        (el) => el.shirtnr != player.shirtnr
      );
      this.posCounter[this.posToNum(player.position)] -= 1;
      console.log(this.posCounter);
    }
  }

  ngOnChanges() {
    this.http
      .get<Footballer[]>(this.playersUrl)
      .subscribe((data: Footballer[]) => {
        this.notSelected = data;
      });
    this.selected = [];
    this.posCounter = [0, 0, 0, 0];
  }

  isAvailable(position: string) {
    const posNum = this.posToNum(position);
    if (this.posCounter[posNum] < this.formation[posNum]) {
      return true;
    } else return false;
  }
}
