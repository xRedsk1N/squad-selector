import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayersComponent } from './players/players.component';
import { ChooseFormationComponent } from './choose-formation/choose-formation.component';
import { ChoosePlayersComponent } from './choose-players/choose-players.component';
import { ListOfPlayersComponent } from './list-of-players/list-of-players.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    PlayersComponent,
    ChooseFormationComponent,
    ChoosePlayersComponent,
    ListOfPlayersComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
